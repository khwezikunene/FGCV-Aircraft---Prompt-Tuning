# FGVCAircraft notes
- Owner: Khwezi
- Cleaning issues: None
- Split verification: 33/33/33 (train/val/test) - match literature

